<?php 	
	include_once 'php/connect.php';
	session_start();
    include 'header.php';
?>

    <body>
            <?php include 'nav.php'; ?>
        <div class="container-inicial">
            <table class="table-inicial">
                <tr>
                    <td><a href></a>
                        <button type="button" class="butao rounded" onclick="window.location.href = 'purchase.php'">Fazer compra</button>
                    </td>
                    <td>
                        <button type="button" class="butao rounded"  onclick="window.location.href = 'products.php'">Produtos</button>
                    </td>
                    <td>
                        <button type="button" class="butao rounded" onclick="window.location.href = 'alert.html'">alertas</button>
                    </td>
                </tr>
                <tr>
                    <td>
                        <button type="button" class="butao rounded" onclick="window.location.href = 'goal.html'">Metas</button>
                    </td>
                    <td>
                        <button type="button" class="butao rounded" style="width: 100%;" onclick="window.location.href = 'discount.html'">Gerenciar descontos</button>
                    </td>
                    <td>
                        <button type="button" class="butao rounded" style="width: 100%;" onclick="window.location.href = 'emplyeeMan.php'">Gerenciar funcionários</button>
                    </td>
                </tr>

            </table>
            
            
        </div>
    </body>
</html>