<?php
    session_start();
    include_once 'php/connect.php';
    include 'php/useFunctions.php';

    #showCadProduct();

    #showProducts();

    #numberOfProduct();
    #include 'header.php';
    
    
?>
    
    <body>
    <form method="POST">
    <input class="form-control" list="datalistOptions" style="width: 100%;" placeholder="Foram encontrados os seguintes produtos com o nome ou id digitados favor selecionar 1" name="produto">
    <datalist id="datalistOptions" name="produto">
        <?php showCadProduct(); ?>
        <input type="text" name="astolfo" value="77"></br>
        <button name="submit" value="add"> add </button>
        <button name="submit" value="edit"> edit </button>
        <button name="submit" value="save"> save </button>
        <button name="submit" value="cancel"> cancel </button>
    </form>

    <datalist id="datalistOptions" name="produto">
            <?php showCadProduct(); ?>
    
    <?php
    
    $roberto = $_POST['astolfo'];
    
    switch($_POST['submit']){
        case 'add':
            echo "add";
            echo $roberto;
            break;
        

        case 'edit':
            echo "edit";
            echo $roberto;
            break;
        
        case 'save':
            echo "save";
            echo $roberto;
            break;
        
        case 'cancel':
            echo "cancel";
            echo $roberto;
            break;
        }
    
    
    
    
    
    ?>

    <script type="text/javascript" language="javascript">
        

    </script>
    

    <!--<script type="text/javascript" language="javascript">
        $(document).ready(function(){
            $('#salvar').click(function(){
                $('#div').load('php/logout.php');
            })
        })
    </script>
    <button type="button" id="salvar">sla bixo </button>
    <div id="div"> </div> -->
    </body>
</html>