<?php 	
	include_once 'php/connect.php';
	session_start();
  include 'header.php';
?>
    <body class="container-inicial" onload="Purchase()">
            <!--<nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom border border-dark">
                <img src="Images/default-user.png" class="navbar-brand border border-primary p-0 m-1" href="#">Bem vindo, Roberto!</a>
                
              
                  <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                      <a class="nav-link" href="telaInicial.html">Tela inicial</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="userPanel">Minhas informações</a>
                    </li>
                  </ul>
                  <button type="button" class="btn btn-danger" onclick="logout()">Sair</button>
              </nav>-->
<!-------------------------------------- Acima daqui é tudo o header ----------------------------------------------->
              
        <div class="d-flex justify-content-center purchase-master bg-white mx-auto">
            <div style="width: 75%" class="m-1">
                <div class="row  m-1" style="width: 99%; text-align: center;">
                    <h1  class="rounded border border-dark">Caixa Aberto</h1>
                </div>
                </br>
                <table class="purchase-table">
                    <tr>
                        <th>id prod.</th>
                        <th>Descrição</th>
                        <th>Qtd</th>
                        <th>Valor unitário</th>
                        <th>total</th>
                    </tr>
                    <tr>
                        <td><p>6578</p></td>
                        <td><p>Escapamento Kodak muito barulhento</p></td>
                        <td><p>2</p></td>
                        <td><p>246,9</p></td>
                        <td><p>493,8</p></td>
                    </tr>
                    <tr>
                        <td><p>6578</p></td>
                        <td><p>Escapamento Kodak muito barulhento</p></td>
                        <td><p>2</p></td>
                        <td><p>246,9</p></td>
                        <td><p>493,8</p></td>
                    </tr>
                    <tr>
                        <td><p>6578</p></td>
                        <td><p>Escapamento Kodak muito barulhento</p></td>
                        <td><p>2</p></td>
                        <td><p>246,9</p></td>
                        <td><p>493,8</p></td>
                    </tr>
                    <tr>
                        <td><p>6578</p></td>
                        <td><p>Escapamento Kodak muito barulhento</p></td>
                        <td><p>2</p></td>
                        <td><p>246,9</p></td>
                        <td><p>493,8</p></td>
                    </tr>
                </table>
            </div>
            <div class="m-2" style="width: 25%; text-align: center;">
                <div style="border: 1px solid black;">
                    <h4 class="bg-black text-white">Valor unitário</h4>
                    <p>246,9</p>
                </div>
            </br>
                <div style="border: 1px solid black;">
                    <h4 class="bg-black text-white">Valor total</h4>
                    <p>246,9</p>
                </div>
            </br>
                <div style="border: 1px solid black;">
                    <h4 class="bg-black text-white">Valor recebido</h4>
                    <p>246,9</p>
                </div>
            </br>
                <div style="border: 1px solid black;">
                    <h4 class="bg-black text-white">Troco</h4>
                    <p>246,9</p>
                </div>
            </br>
                <div style="border: 1px solid black;">
                    <div class="row">
                        <div class="col">
                            <p>m - para voltar a tela inicial</p>
                            <p>F2 - para opção</p>
                            <p>F2 - para opção</p>
                            <p>F2 - para opção</p>
                        </div>
                        <div class="col">
                            <p>F2 - para opção</p>
                            <p>F2 - para opção</p>
                            <p>F2 - para opção</p>
                            <p>F2 - para opção</p>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        <p id="bixo"></p>
    </body>
</html>