<?php


function showCadProduct(){
    include 'connect.php';

    for($i = 0; $i <= numberOfProduct(); $i++){
        $sql = "SELECT * FROM tb_produto WHERE id_produto = '$i'";
        $dados = mysqli_query($conection, $sql);
        $linha = mysqli_fetch_assoc($dados);

        if($linha != null){
            echo '<option value="'. $linha['id_produto']. '">' .$linha['id_produto']. " - " . $linha['nm_produto']. " - ".$linha['ds_marca']. " - ".$linha['ds_modelo'] . "</option>";
            echo "</br>";
        }   
    }
}

function showProducts(){
    include 'connect.php';

    for($i = 0; $i <= numberOfProduct(); $i++){
        $sql = "SELECT p.id_produto, e.ds_quantidade, p.nm_produto, p.vl_produto, p.ds_marca, p.ds_modelo FROM tb_estoque as e 
        INNER JOIN tb_produto as p on e.id_produto = p.id_produto where p.id_produto = $i;";

        $dados = mysqli_query($conection, $sql);
        $linha = mysqli_fetch_assoc($dados);

        if($linha != null){
            echo
            "<tr>
                <td>
                  <p>".$linha['id_produto']."</p>
                </td>

                <td>
                  <p>".$linha['nm_produto']."</p>
                </td>

                <td>
                  <p>".$linha['ds_modelo']."</p>
                </td>
                <td>
                  <p>".$linha['ds_marca']."</p>
                </td>
                <td>
                  <p> R$".$linha['vl_produto']."</p>
                </td>
                <td>
                  <p>".$linha['ds_quantidade']."</p>
                </td>
              </tr>";

        }
        
    }
}

function numberOfProduct(){
  include 'connect.php';
  
  $sql = "SELECT * FROM tb_produto ORDER BY id_produto DESC LIMIT 1";

  $dados = mysqli_query($conection, $sql);

  $linha = mysqli_fetch_assoc($dados);

  return $linha['id_produto'];
    
}