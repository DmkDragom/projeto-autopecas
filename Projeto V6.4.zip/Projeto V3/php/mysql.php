<?php
$sql = array("

    CREATE DATABASE autopecas;",


    "CREATE TABLE tb_pedido (
        id_pedido INT NOT NULL AUTO_INCREMENT,
        id_cliente INT NOT NULL,
        id_funcionario INT NOT NULL,
        vl_total DECIMAL NOT NULL,
        dt_pedido DATE NOT NULL,
        PRIMARY KEY (id_pedido)
    );"
,
    "CREATE TABLE tb_estoque (
        id_estoque INT NOT NULL AUTO_INCREMENT,
        ds_quantidade INT NOT NULL,
        id_produto INT NOT NULL,
        PRIMARY KEY (id_estoque)
    );"
,
    "CREATE TABLE tb_produto (
        id_produto INT NOT NULL AUTO_INCREMENT,
        nm_produto varchar(70) NOT NULL,
        vl_produto DECIMAL NOT NULL,
        PRIMARY KEY (id_produto)
    );"
,
    "CREATE TABLE tb_cliente (
        id_cliente INT NOT NULL AUTO_INCREMENT,
        nm_cliente varchar(50) NOT NULL,
        ds_cpf varchar(15) NOT NULL UNIQUE,
        ds_telefone varchar(20) NOT NULL,
        ds_endereco varchar(50) NOT NULL,
        dt_nascimento DATE NOT NULL,
        PRIMARY KEY (id_cliente)
    );"
,
    "CREATE TABLE tb_metas (
        id_meta INT NOT NULL AUTO_INCREMENT,
        qtd_vendas INT NOT NULL,
        id_funcionario INT NOT NULL,
        PRIMARY KEY (id_meta)
    );"
,
    "CREATE TABLE tb_funcionario (
        id_funcionario INT NOT NULL AUTO_INCREMENT,
        nm_funcionario varchar(60) NOT NULL,
        ds_rg varchar(10) NOT NULL UNIQUE,
        ds_cpf varchar(15) NOT NULL UNIQUE,
        vl_salario DECIMAL NOT NULL,
        ds_endereco varchar(60) NOT NULL,
        dt_nascimento DATE NOT NULL,
        ds_cargo varchar(60) NOT NULL,
        img_funcionário blob,
        ds_senha varchar(50) NOT NULL,
        PRIMARY KEY (id_funcionario)
    );"
,
    "CREATE TABLE tb_desconto (
        id_desconto INT NOT NULL AUTO_INCREMENT,
        cd_desconto varchar(50) NOT NULL,
        vl_desconto DECIMAL NOT NULL,
        PRIMARY KEY (id_desconto)
    );"
,
    "CREATE TABLE tb_pedidoitem (
        id_pedidoitem INT NOT NULL AUTO_INCREMENT,
        id_pedido INT NOT NULL,
        id_produto INT NOT NULL,
        PRIMARY KEY (id_pedidoitem)
    );"
,
    "ALTER TABLE tb_pedido ADD CONSTRAINT tb_pedido_fk0 FOREIGN KEY (id_cliente) REFERENCES tb_cliente(id_cliente);"
,
    "ALTER TABLE tb_pedido ADD CONSTRAINT tb_pedido_fk1 FOREIGN KEY (id_funcionario) REFERENCES tb_funcionario(id_funcionario);"
,
    "ALTER TABLE tb_estoque ADD CONSTRAINT tb_estoque_fk0 FOREIGN KEY (id_produto) REFERENCES tb_produto(id_produto);"
,
    "ALTER TABLE tb_metas ADD CONSTRAINT tb_metas_fk0 FOREIGN KEY (id_funcionario) REFERENCES tb_funcionario(id_funcionario);"
,
    "ALTER TABLE tb_pedidoitem ADD CONSTRAINT tb_pedidoitem_fk0 FOREIGN KEY (id_pedido) REFERENCES tb_pedido(id_pedido);"
,
    "ALTER TABLE tb_pedidoitem ADD CONSTRAINT tb_pedidoitem_fk1 FOREIGN KEY (id_produto) REFERENCES tb_produto(id_produto);"
,
    "INSERT INTO autopecas.tb_funcionario (id_funcionario, nm_funcionario, ds_rg, ds_cpf, vl_salario, ds_endereco, dt_nascimento, ds_cargo, ds_senha) VALUES ('1', 'Jose Marcos dos Santos', '228884795', '322295777432', '1800', 'Rua margarida', '1998-02-10', 'vendedor', 'testeteste');"
,
    "INSERT INTO autopecas.tb_funcionario (id_funcionario, nm_funcionario, ds_rg, ds_cpf, vl_salario, ds_endereco, dt_nascimento, ds_cargo, ds_senha) VALUES ('2', 'Maria do Bairro', '647285947', '22284723363', '1600', 'Rua Jose Freitas', '1990-10-06', 'estoquista', 'maria123');"
,   
    "INSERT INTO autopecas.tb_funcionario (id_funcionario, nm_funcionario, ds_rg, ds_cpf, vl_salario, ds_endereco, dt_nascimento, ds_cargo, ds_senha) VALUES ('3', 'Henrique Gomes da Costa', '738881950', '4222049928', '1600', 'Rua Marcos Gomes da Costa', '1990-10-10', 'estoquista', 'mariazinha');"
,
    "INSERT INTO autopecas.tb_funcionario (id_funcionario, nm_funcionario, ds_rg, ds_cpf, vl_salario, ds_endereco, dt_nascimento, ds_cargo, ds_senha) VALUES ('4', 'Carla Souza', '289994401', '00003944481', '1800', 'Rua Barão do Rio Branco', '1896-05-05', 'vendedor', 'adminadmin');"
, 
    "INSERT INTO autopecas.tb_funcionario (id_funcionario, nm_funcionario, ds_rg, ds_cpf, vl_salario, ds_endereco, dt_nascimento, ds_cargo, ds_senha) VALUES ('5', 'Pedro Henrique Alves Buerno', '999999931', '45772745611', '10000', 'Rua Ilha Bela', '2002-10-10', 'diretor', 'euamoageiza');"
, 
    "INSERT INTO autopecas.tb_funcionario (id_funcionario, nm_funcionario, ds_rg, ds_cpf, vl_salario, ds_endereco, dt_nascimento, ds_cargo, ds_senha) VALUES ('6', 'Frank Henrique Zettler Saraiva', '526492372', '42220344827', '10000', 'Rua Masazo ', '2002-06-10', 'diretor', '12345678');"
, 
    "INSERT INTO autopecas.tb_funcionario (id_funcionario, nm_funcionario, ds_rg, ds_cpf, vl_salario, ds_endereco, dt_nascimento, ds_cargo, ds_senha) VALUES ('7', 'Matheus Teixeira', '287474742', '38375857111', '10000', 'Rua Marcos Jose', '2001-02-02', 'diretor', 'matheus1233444');"
 );