const queryString = window.location.search;

const loginState = new URLSearchParams(queryString).get('login');

const cadastrationState = new URLSearchParams(queryString).get('cadastro');

if(loginState != null){
    alert(loginState);
} else if (cadastrationState != null){
    alert(cadastrationState);
}

function recovery(){
    window.location.assign("Index.php");
}

function logout(){
    $(document).ready(function(){
        $('#sair').click('php/logout.php')
    })
}

//Products below


function start(){
    //modButton(btnState);
    divState = sessionStorage.getItem('divState');
    productsShow(divState);
    modButton(sessionStorage.getItem('btnState'));
    alert(btnState);

}

/*function modButton(state){
    btnSearch = document.getElementById('btnSearchModProd');
    btnEdit = document.getElementById('btnEditModProd');
    btnSave = document.getElementById('btnSaveModProd');
    btnAdd = document.getElementById('btnAddModProd');
    btnCancel = document.getElementById('btnCancelModProd');

    switch(state){
        case 'search':

            document.getElementById('prodId').disabled = true;
            document.getElementById('prodName').disabled = true;
            document.getElementById('prodModel').disabled = true;
            document.getElementById('prodBrand').disabled = true;
            document.getElementById('prodVal').disabled = true;

            sessionStorage.setItem('btnState', 'search');
            break;

        case 'edit':


            document.getElementById('prodId').disabled = false;
            document.getElementById('prodName').disabled = false;
            document.getElementById('prodModel').disabled = false;
            document.getElementById('prodBrand').disabled = false;
            document.getElementById('prodVal').disabled = false;


            sessionStorage.setItem('btnState', 'edit');
            break;
        case 'save':

            sessionStorage.setItem('btnState', 'save');
            break;
        case 'add':

            sessionStorage.setItem('btnState', 'add');
            break;
        case 'cancel':

            sessionStorage.setItem('btnState', 'cancel');
            break;
    }
}*/

function limpa(){
    document.getElementsByTagName('input').value('')
}



function productsShow(state){


    if(state == "search"){
        var div = document.getElementById('searchProd');
        var otherdiv= document.getElementById('modProducts');
        var SomeOtherDiv= document.getElementById('addInventory');

        div.style.visibility = 'visible';
        otherdiv.style.visibility = 'hidden';
        SomeOtherDiv.style.visibility = 'hidden';

        sessionStorage.setItem('divState', 'search');

    } else if (state == "addProduct"){
        var div = document.getElementById('searchProd');
        var otherdiv= document.getElementById('modProducts');
        var SomeOtherDiv= document.getElementById('addInventory');

        div.style.visibility = 'hidden';
        otherdiv.style.visibility = 'visible';
        SomeOtherDiv.style.visibility = 'hidden';

        sessionStorage.setItem('divState', 'addProduct');
    }
    else if(state == "addInventory") {
        var div = document.getElementById('searchProd');
        var otherdiv= document.getElementById('modProducts');
        var SomeOtherDiv= document.getElementById('addInventory');

        div.style.visibility = 'hidden';
        otherdiv.style.visibility = 'hidden';
        SomeOtherDiv.style.visibility = 'visible';

        sessionStorage.setItem('divState', 'addInventory');

        
    } else{
        var div = document.getElementById('searchProd');
        var otherdiv= document.getElementById('modProducts');
        var SomeOtherDiv= document.getElementById('addInventory');

        div.style.visibility = 'hidden';
        otherdiv.style.visibility = 'hidden';
        SomeOtherDiv.style.visibility = 'hidden';

        sessionStorage.setItem('divState', '');

        
    }
}

/*Purchase commands*/
function Purchase(){
    window.addEventListener('keydown', function (e) {
        if(e.key == "m"){
            window.location.assign("telaInicial.php");
        }
      }, false);
}

/*function graphicDraw(){
    var canvas = document.getElementById('canvasgraphic');

    var ctx = canvas.getContext('2d');


    ctx.font = '10px arial';
    ctx.fillText("R$ 2500", 10,20);
    ctx.fillText("R$ 2000", 10,40);
    ctx.fillText("R$ 1500", 10,60);
    ctx.fillText("R$ 1500", 10,80)

    ctx.moveTo(0, 0);
    ctx.lineTo(200, 100);
    ctx.stroke();

}*/

function graphicDraw() {

    var chart = new CanvasJS.Chart("chartContainer", {
        animationEnabled: true,
        theme: "light2",
        title:{
            text: "Vendas no mês"
        },
        data: [{        
            type: "line",
              indexLabelFontSize: 16,
            dataPoints: [
                { y: 450 },
                { y: 414},
                { y: 520, indexLabel: "\u2191 highest",markerColor: "red", markerType: "triangle" },
                { y: 460 },
                { y: 450 },
                { y: 500 },
                { y: 480 },
                { y: 480 },
                { y: 410 , indexLabel: "\u2193 lowest",markerColor: "DarkSlateGrey", markerType: "cross" },
                { y: 500 },
                { y: 480 },
                { y: 700 }
            ]
        }]
    });
    chart.render();
    
    }

function editUserPanel(){
    var camp = document.getElementById('7Func');
        camp.disabled = false;
        camp = document.getElementById('8Func');
        camp.disabled = false;

}
